<?php

if (!defined('_VALID_MOS') && !defined('_JEXEC'))
    die('Direct Access to ' . basename(__FILE__) . ' is not allowed.');

if (!class_exists('vmPSPlugin'))
    require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');

class plgVmPaymentPaymentnepal extends vmPSPlugin
{
    // instance of class
    public static $_this = false;
    
    function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        
        $this->_loggable   = true;
        $this->tableFields = array_keys($this->getTableSQLFields());
        $this->_tablepkey = 'id';
        $this->_tableId = 'id';
        $varsToPush        = array(
		 'payment_logos' => array(
                '',
                'char'
            ),
            'secret_key' => array(
                '',
                'string'
            ),
            'pay_key' => array(
                '',
                'string'
            ),
            'status_success' => array(
                '',
                'char'
            ),
            'status_pending' => array(
                '',
                'char'
            )
        );
        
        $this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
    }
    
    
    protected function getVmPluginCreateTableSQL()
    {
        return $this->createTableSQL('Paymentnepal Table');
    }
    
    function getTableSQLFields()
    {
        $SQLfields = array(
            'id' => 'int(11) unsigned NOT NULL AUTO_INCREMENT',
            'virtuemart_order_id' => 'int(11) UNSIGNED',
            'order_number' => 'char(32)',
            'virtuemart_paymentmethod_id' => 'mediumint(1) UNSIGNED',
            'payment_name' => 'char(255) NOT NULL DEFAULT \'\' ',
            'payment_order_total' => 'decimal(15,2) NOT NULL DEFAULT \'0.00\' ',
            'payment_currency' => 'char(3) '
        );
        
        return $SQLfields;
    }
    
    function plgVmConfirmedOrder($cart, $order)
    {

	if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }
        if (!$this->selectedThisElement($method->payment_element)) {
            return false;
        }
        
        $lang     = JFactory::getLanguage();
        $filename = 'com_virtuemart';
        $lang->load($filename, JPATH_ADMINISTRATOR);
        $vendorId = 0;
        
        $session        = JFactory::getSession();
        $return_context = $session->getId();
        $this->logInfo('plgVmConfirmedOrder order number: ' . $order['details']['BT']->order_number, 'message');
        
        $html = "";
        
        if (!class_exists('VirtueMartModelOrders'))
            require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
        if (!$method->payment_currency)
            $this->getPaymentCurrency($method);
        // END printing out HTML Form code (Payment Extra Info)
        $q = 'SELECT `currency_code_3` FROM `#__virtuemart_currencies` WHERE `virtuemart_currency_id`="' . $method->payment_currency . '" ';
        $db =& JFactory::getDBO();
        $db->setQuery($q);
        
        $currency = strtoupper($db->loadResult());
        if ($currency == 'USD')
          $currency = 'USD';

        $amount = ceil($order['details']['BT']->order_total*100)/100;
        $virtuemart_order_id    = VirtueMartModelOrders::getOrderIdByOrderNumber($order['details']['BT']->order_number);
        
        $desc = "Payment for order №".$order['details']['BT']->order_number;
        //echo $desc_win = ,$desc);
        $success_url = JROUTE::_(JURI::root().'index.php?option=com_virtuemart&view=orders&layout=details&order_number=' . $order['details']['BT']->order_number . '&order_pass=' . $order['details']['BT']->order_pass);
        $fail_url = JROUTE::_(JURI::root().'index.php?option=com_virtuemart&view=pluginresponse&task=pluginUserPaymentCancel&on=' . $order['details']['BT']->order_number . '&pm=' . $order['details']['BT']->virtuemart_paymentmethod_id);
        $result_url = JROUTE::_(JURI::root().'index.php?option=com_virtuemart&view=pluginresponse&task=pluginnotification&pelement=paymentnepal&order_number=' . $virtuemart_order_id);
		
		$jmlThisDocument = JFactory::getDocument();
		switch ($jmlThisDocument->language){
			case 'en-gb':
				$language = 'en';
				break;
			case 'ru-ru':
				$language = 'ru';
				break;
			default:
				$language = 'en';
		}
        
        $razd=':' ;
        $order_number=$order['details']['BT']->order_number;;
        //$SignatureValue =      md5($method->merchant_id.$razd.$amount.$razd.$order_number.$razd.$method->secret_key);
        
        $this->_virtuemart_paymentmethod_id      = $order['details']['BT']->virtuemart_paymentmethod_id;
        $dbValues['payment_name']                = $this->renderPluginName($method);
        $dbValues['order_number']                = $order['details']['BT']->order_number;
        $dbValues['virtuemart_paymentmethod_id'] = $this->_virtuemart_paymentmethod_id;
        $dbValues['payment_currency']            = $currency;
        $dbValues['payment_order_total']         = $amount;
        $this->storePSPluginInternalData($dbValues);
        // $desc = "Payment for order №".$order['details']['BT']->order_number;
        $desc = "Payment for order №".$order['details']['BT']->order_number;
        $html = '<form method="post" action="https://pay.paymentnepal.com/alba/input" name="vm_paymentnepal_form">';
        $html .= '<input type="hidden" name="key" value="'.$method->pay_key.'">';
        $html .= '<input type="hidden" name="cost" value="'.$amount.'">'; 
        $html .= '<input type="hidden" name="order_id" value="'.$virtuemart_order_id.'">'; 
        $html .= '<input type="hidden" name="comment" value="'.$desc.'">';  
        $html .= '<input type="hidden" name="name" value="'.$desc.'">';
        //$html .= '<input type="submit"/>';
        $html .= '</form>';
        $html .= '<script type="text/javascript">';
        $html .= 'document.forms.vm_paymentnepal_form.submit();';
        $html .= '</script>';
        return $this->processConfirmedOrderPaymentResponse(true, $cart, $order, $html, $this->renderPluginName($method, $order), $method->status_pending);
    }
    
    function plgVmOnShowOrderBEPayment($virtuemart_order_id, $virtuemart_payment_id)
    {
        if (!$this->selectedThisByMethodId($virtuemart_payment_id)) {
            return null; // Another method was selected, do nothing
        }
        
        $db = JFactory::getDBO();
        $q  = 'SELECT * FROM `' . $this->_tablename . '` ' . 'WHERE `virtuemart_order_id` = ' . $virtuemart_order_id;
        $db->setQuery($q);
        if (!($paymentTable = $db->loadObject())) {
            vmWarn(500, $q . " " . $db->getErrorMsg());
            return '';
        }
        $this->getPaymentCurrency($paymentTable);
        
        $html = '<table class="adminlist">' . "\n";
        $html .= $this->getHtmlHeaderBE();
        $html .= $this->getHtmlRowBE('STANDARD_PAYMENT_NAME', $paymentTable->payment_name);
        $html .= $this->getHtmlRowBE('STANDARD_PAYMENT_TOTAL_CURRENCY', $paymentTable->payment_order_total . ' ' . $paymentTable->payment_currency);
        $html .= '</table>' . "\n";
        return $html;
    }
    
    function getCosts(VirtueMartCart $cart, $method, $cart_prices)
    {
        return 0;
    }
    
    protected function checkConditions($cart, $method, $cart_prices)
    {
        return true;
    }
    
    function plgVmOnStoreInstallPaymentPluginTable($jplugin_id)
    {
        return $this->onStoreInstallPluginTable($jplugin_id);
    }
    
    public function plgVmOnSelectCheckPayment(VirtueMartCart $cart)
    {
        return $this->OnSelectCheck($cart);
    }
    
    public function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn)
    {
        return $this->displayListFE($cart, $selected, $htmlIn);
    }
    
    public function plgVmonSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name)
    {
        return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
    }
    
    function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId)
    {
        if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }
        if (!$this->selectedThisElement($method->payment_element)) {
            return false;
        }
        $this->getPaymentCurrency($method);
        
        $paymentCurrencyId = $method->payment_currency;
    }
    
    function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array())
    {
        return $this->onCheckAutomaticSelected($cart, $cart_prices);
    }
    
    public function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name)
    {
        $this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
    }
    
    function plgVmonShowOrderPrintPayment($order_number, $method_id)
    {
        return $this->onShowOrderPrint($order_number, $method_id);
    }
    
    function plgVmDeclarePluginParamsPayment($name, $id, &$data)
    {
        return $this->declarePluginParams('payment', $name, $id, $data);
    }
    
    function plgVmSetOnTablePluginParamsPayment($name, $id, &$table)
    {
        return $this->setOnTablePluginParams($name, $id, $table);
    }
    
    protected function displayLogos($logo_list)
    {
        $img = "";
        
        if (!(empty($logo_list))) {
            $url = JURI::root() . str_replace('\\', '/', str_replace(JPATH_ROOT, '', dirname(__FILE__))) . '/';
            if (!is_array($logo_list))
                $logo_list = (array) $logo_list;
            foreach ($logo_list as $logo) {
                $alt_text = substr($logo, 0, strpos($logo, '.'));
               // $img .= '<img align="middle" src="' . $url . $logo . '"  alt="' . $alt_text . '" /> ';
            }
        }
        return $img;
    }
    
    public function plgVmOnPaymentNotification()
    {
        if (JRequest::getVar('pelement') != 'paymentnepal') {
            return null;
        }
        if (!class_exists('VirtueMartModelOrders'))
            require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');

        //$orderid      = JRequest::getVar('InvId');
        $virtuemart_order_id = $_REQUEST['order_id'];//VirtueMartModelOrders::getOrderIdByOrderNumber($orderid);
        $payment      = $this->getDataByOrderId($virtuemart_order_id);
        $method       = $this->getVmPluginMethod($payment->virtuemart_paymentmethod_id);

        if ($method)
        {
          $params = array(  'tid'            =>  $_REQUEST['tid'],
                   'name'           =>  urldecode($_REQUEST['name']), 
                   'comment'        =>  $_REQUEST['comment'],
                   'partner_id'     =>  $_REQUEST['partner_id'],
                   'service_id'     =>  $_REQUEST['service_id'],
                   'order_id'       =>  $_REQUEST['order_id'],
                   'type'           =>  $_REQUEST['type'],
                   'partner_income' =>  $_REQUEST['partner_income'],
                   'system_income'  =>  $_REQUEST['system_income'],
                   'test'           =>  $_REQUEST['test']
                );           
              $check = md5(join('', array_values($params)) . $method->secret_key);

          if ($check !=$_REQUEST["check"] )
            {
              echo "bad sign\n";
              exit();
            }
                  $status = $method->status_success;
                  $order['order_status']        = $status;
                  $order['virtuemart_order_id'] = $virtuemart_order_id;
                  $order['customer_notified']   = 0;
                  $order['comments']            = JTExt::sprintf('VMPAYMENT_PAYMENTNEPAL_PAYMENT_CONFIRMED', $payment->order_number);
                  if (!class_exists('VirtueMartModelOrders'))
                    require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
                  $modelOrder = new VirtueMartModelOrders();
                  ob_start();
                  $modelOrder->updateStatusForOneOrder($virtuemart_order_id, $order, true);
                  ob_end_clean();
                  echo "OK, $payment->order_number\n";
        }
        else
          echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><response><status>no</status><err_msg>Incorrect payment method</err_msg></response>";
        
        exit;
        return null;
    }
    
    function plgVmOnPaymentResponseReceived(&$html)
    {
        // the payment itself should send the parameter needed;
        
        $virtuemart_paymentmethod_id = JRequest::getInt('pm', 0);
        //print_r($_REQUEST);
        $vendorId = 0;
        if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }
        if (!$this->selectedThisElement($method->payment_element)) {
            return false;
        }
        
        if (!class_exists('VirtueMartModelOrders'))
            require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
        
        $order_number        = JRequest::getVar('InvId'); 
        $virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber($order_number);
        $payment_name        = $this->renderPluginName($method);
        $html .= '<table>' . "\n";
        $html .= $this->getHtmlRow('PAYMENTNEPAL_PAYMENT_NAME', $payment_name);
        $html .= $this->getHtmlRow('PAYMENTNEPAL_PAYMENT_NAME_ORDER_NUMBER', $order_number);
        $html .= $this->getHtmlRow('PAYMENTNEPAL_PAYMENT_NAME_STATUS', JText::_('VMPAYMENT_PAYMENTNEPAL_PAYMENT_NAME_STATUS_SUCCESS'));
        
        $html .= '</table>' . "\n";
        
        if ($virtuemart_order_id) {
            if (!class_exists('VirtueMartCart'))
                require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');
            // get the correct cart / session
            $cart = VirtueMartCart::getCart();
            
            // send the email ONLY if payment has been accepted
            if (!class_exists('VirtueMartModelOrders'))
                require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
            $order      = new VirtueMartModelOrders();
            $orderitems = $order->getOrder($virtuemart_order_id);
            //print_r($orderitems);
            //$cart->sentOrderConfirmedEmail($orderitems);
            $cart->emptyCart();
        }
        
        return true;
    }
    
    function plgVmOnUserPaymentCancel()
    {
        if (!class_exists('VirtueMartModelOrders'))
            require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
        
        $order_number = JRequest::getVar('InvId');
        if (!$order_number)
            return false;
        $db    = JFactory::getDBO();
        $query = 'SELECT ' . $this->_tablename . '.`virtuemart_order_id` FROM ' . $this->_tablename . " WHERE  `order_number`= '" . $order_number . "'";
        
        $db->setQuery($query);
        $virtuemart_order_id = $db->loadResult();
        
        if (!$virtuemart_order_id) {
            return null;
        }
        $this->handlePaymentUserCancel($virtuemart_order_id);
        
        return true;
    }

    private function notifyCustomer($order, $order_info)
    {
        $lang     = JFactory::getLanguage();
        $filename = 'com_virtuemart';
        $lang->load($filename, JPATH_ADMINISTRATOR);
        if (!class_exists('VirtueMartControllerVirtuemart'))
            require(JPATH_VM_SITE . DS . 'controllers' . DS . 'virtuemart.php');
        
        if (!class_exists('shopFunctionsF'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
        $controller = new VirtueMartControllerVirtuemart();
        $controller->addViewPath(JPATH_VM_ADMINISTRATOR . DS . 'views');
        
        $view = $controller->getView('orders', 'html');
        if (!$controllerName)
            $controllerName = 'orders';
        $controllerClassName = 'VirtueMartController' . ucfirst($controllerName);
        if (!class_exists($controllerClassName))
            require(JPATH_VM_SITE . DS . 'controllers' . DS . $controllerName . '.php');
        
        $view->addTemplatePath(JPATH_COMPONENT_ADMINISTRATOR . '/views/orders/tmpl');
        
        $db = JFactory::getDBO();
        $q  = "SELECT CONCAT_WS(' ',first_name, middle_name , last_name) AS full_name, email, order_status_name
			FROM #__virtuemart_order_userinfos
			LEFT JOIN #__virtuemart_orders
			ON #__virtuemart_orders.virtuemart_user_id = #__virtuemart_order_userinfos.virtuemart_user_id
			LEFT JOIN #__virtuemart_orderstates
			ON #__virtuemart_orderstates.order_status_code = #__virtuemart_orders.order_status
			WHERE #__virtuemart_orders.virtuemart_order_id = '" . $order['virtuemart_order_id'] . "'
			AND #__virtuemart_orders.virtuemart_order_id = #__virtuemart_order_userinfos.virtuemart_order_id";
        $db->setQuery($q);
        $db->query();
        $view->user  = $db->loadObject();
        $view->order = $order;
        JRequest::setVar('view', 'orders');
        $user = $this->sendVmMail($view, $order_info['details']['BT']->email, false);
        if (isset($view->doVendor)) {
            $this->sendVmMail($view, $view->vendorEmail, true);
        }
    }

    private function sendVmMail(&$view, $recipient, $vendor = false)
    {
        ob_start();
        $view->renderMailLayout($vendor, $recipient);
        $body = ob_get_contents();
        ob_end_clean();
        
        $subject = (isset($view->subject)) ? $view->subject : JText::_('COM_VIRTUEMART_DEFAULT_MESSAGE_SUBJECT');
        $mailer  = JFactory::getMailer();
        $mailer->addRecipient($recipient);
        $mailer->setSubject($subject);
        $mailer->isHTML(VmConfig::get('order_mail_html', true));
        $mailer->setBody($body);
        
        if (!$vendor) {
            $replyto[0] = $view->vendorEmail;
            $replyto[1] = $view->vendor->vendor_name;
            $mailer->addReplyTo($replyto);
        }
        
        if (isset($view->mediaToSend)) {
            foreach ((array) $view->mediaToSend as $media) {
                $mailer->addAttachment($media);
            }
        }
        return $mailer->Send();
    }
  function plgVmDeclarePluginParamsPaymentVM3( &$data) {
    return $this->declarePluginParams('payment', $data);
  }
    
}
